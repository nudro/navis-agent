import { useState, useEffect, useRef } from 'react'
import './Chat.css'

function Chat() {
  const [messages, setMessages] = useState([])
  const [inputValue, setInputValue] = useState('')
  const [isConnected, setIsConnected] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const wsRef = useRef(null)
  const messagesEndRef = useRef(null)
  const chatBodyRef = useRef(null)
  const textareaRef = useRef(null)

  useEffect(() => {
    // Connect to chat WebSocket
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const host = window.location.host
    const wsUrl = `${protocol}//${host}/ws/chat`
    
    const ws = new WebSocket(wsUrl)
    wsRef.current = ws

    ws.onopen = () => {
      console.log('Chat WebSocket connected')
      setIsConnected(true)
    }

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data)
      
      if (data.type === 'system') {
        setMessages(prev => [...prev, {
          role: 'system',
          content: data.message,
          timestamp: new Date()
        }])
      } else if (data.type === 'agent') {
        setIsTyping(false)
        
        // Check if plot data is included
        if (data.plot_data) {
          // Open plot in new tab
          openPlotWindow(data.plot_data)
        }
        
        setMessages(prev => [...prev, {
          role: 'agent',
          content: data.message,
          timestamp: new Date(),
          success: data.success,
          error: data.error,
          plot_data: data.plot_data
        }])
      } else if (data.type === 'error') {
        setIsTyping(false)
        setMessages(prev => [...prev, {
          role: 'system',
          content: `Error: ${data.message}`,
          timestamp: new Date(),
          isError: true
        }])
      }
    }

    ws.onerror = (error) => {
      console.error('Chat WebSocket error:', error)
      setIsConnected(false)
      setIsTyping(false)
    }

    ws.onclose = () => {
      console.log('Chat WebSocket disconnected')
      setIsConnected(false)
      setIsTyping(false)
    }

    // Cleanup on unmount
    return () => {
      if (wsRef.current) {
        wsRef.current.close()
      }
    }
  }, [])

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [messages, isTyping])

  const handleSend = () => {
    if (!inputValue.trim() || !isConnected || isTyping) {
      return
    }

    const userMessage = inputValue.trim()
    
    // Add user message to chat
    setMessages(prev => [...prev, {
      role: 'user',
      content: userMessage,
      timestamp: new Date()
    }])

    // Send to WebSocket
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ message: userMessage }))
      setIsTyping(true)
      setInputValue('')
    }
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`
    }
  }, [inputValue])

  const openPlotWindow = (plotData) => {
    // Create a new window with plot
    const plotWindow = window.open('', '_blank', 'width=1000,height=600')
    
    if (!plotWindow) {
      alert('Please allow pop-ups to view plots')
      return
    }
    
    // Write HTML content with Chart.js
    plotWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>${plotData.title}</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            margin: 0;
            padding: 20px;
            background: #0d1117;
            color: #c9d1d9;
          }
          .container {
            max-width: 1200px;
            margin: 0 auto;
            background: #161b22;
            padding: 30px;
            border-radius: 8px;
            border: 1px solid #30363d;
          }
          h1 {
            margin-top: 0;
            color: #58a6ff;
            font-size: 24px;
          }
          canvas {
            background: #0d1117;
            border-radius: 4px;
          }
          .info {
            margin-top: 20px;
            padding: 15px;
            background: #21262d;
            border-radius: 4px;
            border-left: 3px solid #58a6ff;
            font-size: 14px;
            color: #8b949e;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>${plotData.title}</h1>
          <canvas id="plotChart"></canvas>
          <div class="info">
            Track ID: ${plotData.track_id} | Metric: ${plotData.metric} | Data points: ${plotData.values.length}
          </div>
        </div>
        <script>
          const ctx = document.getElementById('plotChart').getContext('2d');
          const chart = new Chart(ctx, {
            type: 'line',
            data: {
              labels: ${JSON.stringify(plotData.frames)},
              datasets: [{
                label: '${plotData.label}',
                data: ${JSON.stringify(plotData.values)},
                borderColor: 'rgb(88, 166, 255)',
                backgroundColor: 'rgba(88, 166, 255, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 2,
                pointHoverRadius: 5
              }]
            },
            options: {
              responsive: true,
              maintainAspectRatio: true,
              plugins: {
                legend: {
                  display: true,
                  labels: {
                    color: '#c9d1d9'
                  }
                },
                tooltip: {
                  mode: 'index',
                  intersect: false,
                  backgroundColor: '#161b22',
                  titleColor: '#c9d1d9',
                  bodyColor: '#c9d1d9',
                  borderColor: '#30363d',
                  borderWidth: 1
                }
              },
              scales: {
                x: {
                  title: {
                    display: true,
                    text: 'Frame Number',
                    color: '#8b949e'
                  },
                  ticks: {
                    color: '#8b949e'
                  },
                  grid: {
                    color: '#21262d'
                  }
                },
                y: {
                  title: {
                    display: true,
                    text: '${plotData.label}',
                    color: '#8b949e'
                  },
                  ticks: {
                    color: '#8b949e'
                  },
                  grid: {
                    color: '#21262d'
                  }
                }
              },
              interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
              }
            }
          });
        </script>
      </body>
      </html>
    `)
    plotWindow.document.close()
  }

  const formatMessage = (message) => {
    // Format multi-line messages with proper typography
    const content = message.content
    // Split by lines and preserve formatting
    const lines = content.split('\n')
    
    return lines.map((line, index) => {
      // Check if line looks like code (starts with spaces/tabs or contains code patterns)
      const isCodeLine = /^\s{2,}/.test(line) || /[{}();=]/.test(line)
      
      return (
        <span key={index}>
          {isCodeLine ? (
            <code className="inline-code">{line}</code>
          ) : (
            line
          )}
          {index < lines.length - 1 && <br />}
        </span>
      )
    })
  }

  return (
    <div className="chat">
      <div className="chat-header">
        <div className="chat-title">Agent</div>
        <div className="chat-status">
          <span className={`chat-status-indicator ${isConnected ? 'connected' : 'disconnected'}`}></span>
          <span className="chat-status-text">{isConnected ? 'Connected' : 'Disconnected'}</span>
        </div>
      </div>
      <div className="chat-body" ref={chatBodyRef}>
        <div className="chat-messages">
          {messages.length === 0 ? (
            <div className="chat-empty">
              <p className="chat-empty-title">Start a conversation</p>
              <p className="chat-empty-hint">Ask about tracked vessels, metrics, or events</p>
              <div className="chat-examples">
                <p className="chat-examples-title">Examples</p>
                <ul className="chat-examples-list">
                  <li>How many vessels are tracked?</li>
                  <li>List tracked vessels</li>
                  <li>Show events</li>
                  <li>Show metrics</li>
                  <li>Draw me a plot of speed for track 1</li>
                </ul>
              </div>
            </div>
          ) : (
            messages.map((message, index) => (
              <div key={index} className={`chat-message chat-message-${message.role}`}>
                {message.role === 'agent' && <div className="chat-message-rule"></div>}
                <div className="chat-message-inner">
                  <div className={`chat-message-text ${message.isError ? 'error' : ''}`}>
                    {formatMessage(message)}
                  </div>
                  <div className="chat-message-meta">
                    <span className="chat-message-role">{message.role === 'user' ? 'You' : message.role === 'agent' ? 'Agent' : 'System'}</span>
                    <span className="chat-message-time">{message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </div>
              </div>
            ))
          )}
          {isTyping && (
            <div className="chat-message chat-message-agent">
              <div className="chat-message-rule"></div>
              <div className="chat-message-inner">
                <div className="chat-message-text typing-indicator">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
      <div className="chat-input-container">
        <textarea
          ref={textareaRef}
          className="chat-input"
          placeholder={isConnected ? "Type your message..." : "Connecting..."}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyPress}
          disabled={!isConnected || isTyping}
          rows={1}
        />
        <button
          className="chat-send-button"
          onClick={handleSend}
          disabled={!inputValue.trim() || !isConnected || isTyping}
          aria-label="Send message"
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1.5 1.5L14.5 8L1.5 14.5V9.5L10.5 8L1.5 6.5V1.5Z" fill="currentColor"/>
          </svg>
        </button>
      </div>
    </div>
  )
}

export default Chat

