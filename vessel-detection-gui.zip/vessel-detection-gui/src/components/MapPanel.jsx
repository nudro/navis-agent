import { useState } from 'react'
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import './MapPanel.css'

// Fix for default marker icons in React-Leaflet
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
})

// Component to access map instance for reset
function MapController({ resetTrigger, center, zoom }) {
  const map = useMap()
  
  if (resetTrigger > 0) {
    map.setView(center, zoom)
  }
  
  return null
}

function MapPanel() {
  const [resetTrigger, setResetTrigger] = useState(0)

  const DEFAULT_CENTER = [30.9, 122.1] // Synthetic Western Pacific harbor
  const DEFAULT_ZOOM = 10

  // Sample vessel markers - Western Pacific harbor area
  const vesselMarkers = [
    { id: 1, name: 'Vessel Alpha', position: [30.92, 122.12] },
    { id: 2, name: 'Vessel Beta', position: [30.88, 122.08] },
    { id: 3, name: 'Vessel Gamma', position: [30.91, 122.15] },
    { id: 4, name: 'Vessel Delta', position: [30.89, 122.11] },
  ]

  const defaultCenter = DEFAULT_CENTER
  const defaultZoom = DEFAULT_ZOOM

  const handleResetView = () => {
    setResetTrigger(prev => prev + 1)
  }

  return (
    <div className="map-panel-container">
      <MapContainer
        center={defaultCenter}
        zoom={defaultZoom}
        style={{ height: '100%', width: '100%' }}
        className="nautical-map"
      >
        <MapController resetTrigger={resetTrigger} center={defaultCenter} zoom={defaultZoom} />
        {/* Base layer: OpenStreetMap */}
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {/* Overlay layer: OpenSeaMap seamarks */}
        <TileLayer
          attribution='&copy; <a href="https://www.openseamap.org">OpenSeaMap</a> contributors'
          url="https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png"
          opacity={0.7}
        />

        {/* Vessel markers */}
        {vesselMarkers.map((vessel) => (
          <Marker key={vessel.id} position={vessel.position}>
            <Popup>
              <div className="vessel-popup">
                <strong>{vessel.name}</strong>
                <br />
                <span className="vessel-coords">
                  {vessel.position[0].toFixed(4)}, {vessel.position[1].toFixed(4)}
                </span>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* Overlay controls */}
      <div className="map-controls">
        <div className="map-control-group">
          <button className="map-control-button" onClick={handleResetView}>
            Reset view
          </button>
        </div>
      </div>
    </div>
  )
}

export default MapPanel

