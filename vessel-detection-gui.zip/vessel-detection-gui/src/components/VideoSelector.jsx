import { useState, useEffect } from 'react'
import './VideoSelector.css'

function VideoSelector({ onVideoSelect }) {
  const [videos, setVideos] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedVideo, setSelectedVideo] = useState('')

  useEffect(() => {
    loadVideos()
  }, [])

  const loadVideos = async () => {
    try {
      const response = await fetch('/api/videos')
      if (!response.ok) {
        throw new Error('Failed to load videos')
      }
      const data = await response.json()
      setVideos(data.videos || [])
    } catch (error) {
      console.error('Error loading videos:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSelect = (event) => {
    const selectedPath = event.target.value
    if (selectedPath) {
      setSelectedVideo(selectedPath)
      onVideoSelect(selectedPath)
    }
  }

  return (
    <div className="video-selector">
      <h2>Select Video</h2>
      {loading ? (
        <div className="loading">Loading videos...</div>
      ) : videos.length === 0 ? (
        <div className="no-videos">No videos found in /media</div>
      ) : (
        <select 
          className="video-dropdown"
          value={selectedVideo}
          onChange={handleSelect}
        >
          <option value="">-- Select a video --</option>
          {videos.map((video, index) => (
            <option key={index} value={video.path}>
              {video.name}
            </option>
          ))}
        </select>
      )}
    </div>
  )
}

export default VideoSelector

